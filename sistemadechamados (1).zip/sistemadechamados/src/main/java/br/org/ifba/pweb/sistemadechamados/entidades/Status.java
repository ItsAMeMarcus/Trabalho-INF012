package br.org.ifba.pweb.sistemadechamados.entidades;

public enum Status {
	EM_ABERTO, CONCLUIDO;
}
