package br.org.ifba.pweb.sistemadechamados;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemadechamadosApplicationTests {

	@Test
	void contextLoads() {
	}

}
